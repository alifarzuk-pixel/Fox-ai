
import { GoogleGenAI } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const getCodeEdit = async (prompt: string, currentCode: string, fileName: string) => {
  const ai = getAIClient();
  const fullPrompt = `User wants to edit this file: ${fileName}.
Current content:
\`\`\`
${currentCode}
\`\`\`

User instruction: ${prompt}

Provide only the updated code block. No explanations. Return only the code within triple backticks.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: fullPrompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.1,
      },
    });

    const text = response.text || '';
    const match = text.match(/```(?:[a-z]*)\n?([\s\S]*?)```/);
    return match ? match[1].trim() : text.replace(/```[a-z]*\n|```/g, '').trim();
  } catch (error) {
    console.error("AI Error:", error);
    return null;
  }
};

export const getChatResponseStream = async (
  history: { role: string, content: string }[], 
  userMessage: string, 
  contextCode?: string,
  onChunk?: (text: string) => void
) => {
  const ai = getAIClient();
  
  const contents = history.map(h => ({
    role: h.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: h.content }]
  }));

  const contextPart = contextCode ? `\n\nContext code provided (use this for reference):\n\`\`\`typescript\n${contextCode}\n\`\`\`` : "";
  
  contents.push({
    role: 'user',
    parts: [{ text: userMessage + contextPart }]
  });

  try {
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3-pro-preview',
      contents: contents as any,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    let fullText = "";
    for await (const chunk of responseStream) {
      const chunkText = chunk.text;
      if (chunkText) {
        fullText += chunkText;
        onChunk?.(fullText);
      }
    }
    return fullText;
  } catch (error) {
    console.error("Chat Error:", error);
    return "Sorry, I encountered an error processing your request.";
  }
};
