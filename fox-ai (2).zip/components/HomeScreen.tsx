
import React from 'react';
import { Sparkles, FilePlus, BookOpen, Code, Command, Terminal, Cpu, FolderOpen, Globe } from 'lucide-react';

interface HomeScreenProps {
  onNewFile: () => void;
  onUploadClick: () => void;
  onPromptSubmit: (prompt: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onNewFile, onUploadClick, onPromptSubmit }) => {
  const [prompt, setPrompt] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onPromptSubmit(prompt);
      setPrompt('');
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-[#0d0d0d] p-8 overflow-y-auto">
      {/* Hero Section */}
      <div className="max-w-4xl w-full space-y-12">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-medium">
            <Sparkles size={14} />
            <span>Fox AI Powered Development</span>
          </div>
          <h1 className="text-6xl font-bold tracking-tight text-white bg-gradient-to-b from-white to-gray-500 bg-clip-text text-transparent pb-2">
            The AI code editor for everyone.
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto leading-relaxed">
            Experience the future of software engineering. Build, refactor, and deploy apps in seconds with the help of a world-class AI assistant.
          </p>
        </div>

        {/* Central Prompt Area */}
        <div className="relative group">
          <form onSubmit={handleSubmit} className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000"></div>
            <div className="relative flex items-center bg-[#141414] border border-[#262626] rounded-xl p-2 focus-within:border-blue-500/50 transition-all shadow-2xl">
              <div className="pl-4 text-gray-500">
                <Sparkles size={20} />
              </div>
              <input
                type="text"
                placeholder="What are we building today? (e.g., 'A real-time chat app with React')"
                className="w-full bg-transparent border-none outline-none text-white px-4 py-4 text-lg placeholder:text-gray-600"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              <button 
                type="submit"
                className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-3 rounded-lg text-sm font-bold transition-all flex items-center gap-2 shadow-xl shadow-blue-900/40 active:scale-95"
              >
                Start Building
              </button>
            </div>
          </form>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button 
            onClick={onNewFile}
            className="flex flex-col items-start p-8 rounded-2xl bg-[#141414] border border-[#262626] hover:border-blue-500/30 hover:bg-[#1a1a1a] transition-all text-left group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <FilePlus size={80} />
            </div>
            <div className="p-4 rounded-xl bg-emerald-500/10 text-emerald-500 mb-6 group-hover:scale-110 transition-transform shadow-lg">
              <FilePlus size={32} />
            </div>
            <h3 className="text-white text-xl font-bold mb-2">New Project</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Bootstrap a fresh workspace with editor, terminal, and AI ready to go.</p>
          </button>

          <button 
            onClick={() => onPromptSubmit("Create a high-performance backend server using Node.js and TypeScript.")}
            className="flex flex-col items-start p-8 rounded-2xl bg-[#141414] border border-[#262626] hover:border-blue-500/30 hover:bg-[#1a1a1a] transition-all text-left group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <Globe size={80} />
            </div>
            <div className="p-4 rounded-xl bg-blue-500/10 text-blue-500 mb-6 group-hover:scale-110 transition-transform shadow-lg">
              <Globe size={32} />
            </div>
            <h3 className="text-white text-xl font-bold mb-2">Create Server</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Provision a new backend infrastructure and define server-side logic.</p>
          </button>

          <button 
            onClick={onUploadClick}
            className="flex flex-col items-start p-8 rounded-2xl bg-[#141414] border border-[#262626] hover:border-blue-500/30 hover:bg-[#1a1a1a] transition-all text-left group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <FolderOpen size={80} />
            </div>
            <div className="p-4 rounded-xl bg-orange-500/10 text-orange-500 mb-6 group-hover:scale-110 transition-transform shadow-lg">
              <FolderOpen size={32} />
            </div>
            <h3 className="text-white text-xl font-bold mb-2">Open Folder</h3>
            <p className="text-gray-500 text-sm leading-relaxed">Import an existing project and let Fox AI analyze your codebase.</p>
          </button>
        </div>

        {/* Shortcuts & Info */}
        <div className="pt-12 border-t border-[#1a1a1a] grid grid-cols-2 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-gray-600 flex items-center gap-2">
              <Command size={14} />
              Navigation
            </h4>
            <ul className="space-y-3 text-sm text-gray-500">
              <li className="flex justify-between items-center"><span>Quick Open</span> <kbd className="bg-[#1a1a1a] px-2 py-0.5 rounded border border-[#333] text-[10px] font-mono">⌘P</kbd></li>
              <li className="flex justify-between items-center"><span>Toggle AI</span> <kbd className="bg-[#1a1a1a] px-2 py-0.5 rounded border border-[#333] text-[10px] font-mono">⌘L</kbd></li>
              <li className="flex justify-between items-center"><span>Terminal</span> <kbd className="bg-[#1a1a1a] px-2 py-0.5 rounded border border-[#333] text-[10px] font-mono">⌘`</kbd></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-gray-600 flex items-center gap-2">
              <Terminal size={14} />
              Core Files
            </h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="hover:text-blue-400 cursor-pointer transition-colors flex items-center gap-2"><Code size={14} /> index.ts</li>
              <li className="hover:text-blue-400 cursor-pointer transition-colors flex items-center gap-2"><Code size={14} /> package.json</li>
              <li className="hover:text-blue-400 cursor-pointer transition-colors flex items-center gap-2"><Code size={14} /> tsconfig.json</li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-gray-600 flex items-center gap-2">
              <Cpu size={14} />
              Engine
            </h4>
            <div className="text-sm text-gray-500 space-y-1">
              <p className="font-bold text-gray-300">Gemini 3 Pro</p>
              <p className="text-[12px]">Optimized for Context</p>
              <p className="text-[12px] text-emerald-500 font-medium">System Online</p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-gray-600 flex items-center gap-2">
              <Sparkles size={14} />
              Developer
            </h4>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-sm text-blue-400">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                <span className="font-medium">Fox AI Assistant</span>
              </div>
              <p className="text-[11px] text-gray-600 italic leading-relaxed">"Standing by to refactor, debug, or build from scratch."</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
