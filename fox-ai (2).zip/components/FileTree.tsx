
import React, { useState } from 'react';
import { FileNode } from '../types';
import { File, ChevronRight, ChevronDown, Folder } from 'lucide-react';

interface FileTreeProps {
  nodes: FileNode[];
  activeFileId: string | null;
  onSelectFile: (id: string) => void;
  level: number;
}

export const FileTree: React.FC<FileTreeProps> = ({ nodes, activeFileId, onSelectFile, level }) => {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ root: true });

  const toggleExpand = (id: string) => {
    setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-1">
      {nodes.map(node => (
        <div key={node.id}>
          <div
            className={`flex items-center gap-2 py-1 px-2 rounded cursor-pointer transition-colors group ${
              activeFileId === node.id ? 'bg-[#2b2b2b] text-white' : 'hover:bg-[#1a1a1a]'
            }`}
            style={{ paddingLeft: `${level * 12 + 8}px` }}
            onClick={() => {
              if (node.type === 'folder') {
                toggleExpand(node.id);
              } else {
                onSelectFile(node.id);
              }
            }}
          >
            {node.type === 'folder' ? (
              <>
                {expanded[node.id] ? (
                  <ChevronDown size={14} className="text-gray-500" />
                ) : (
                  <ChevronRight size={14} className="text-gray-500" />
                )}
                <Folder size={14} className="text-blue-400 fill-blue-400/20" />
              </>
            ) : (
              <File size={14} className="text-gray-400" />
            )}
            <span className="text-sm truncate">{node.name}</span>
          </div>

          {node.type === 'folder' && expanded[node.id] && node.children && (
            <FileTree
              nodes={node.children}
              activeFileId={activeFileId}
              onSelectFile={onSelectFile}
              level={level + 1}
            />
          )}
        </div>
      ))}
    </div>
  );
};
