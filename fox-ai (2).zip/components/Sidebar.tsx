
import React, { useRef } from 'react';
import { FileTree } from './FileTree';
import { FileNode } from '../types';
import { Settings, User, FilePlus, Home, FolderOpen, Globe } from 'lucide-react';

interface SidebarProps {
  files: FileNode[];
  activeFileId: string | null;
  onSelectFile: (id: string) => void;
  onNewFile: () => void;
  onUploadFile: (name: string, content: string) => void;
  onGoHome: () => void;
  onToggleServer: () => void;
  isServerView: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  files, 
  activeFileId, 
  onSelectFile, 
  onNewFile, 
  onUploadFile,
  onGoHome,
  onToggleServer,
  isServerView
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        onUploadFile(file.name, content);
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d]">
      {/* Project Header */}
      <div className="p-4 flex items-center justify-between border-b border-[#1a1a1a]">
        <div 
          onClick={onGoHome}
          className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors group"
        >
          <Home size={16} className={`${!activeFileId && !isServerView ? 'text-blue-500' : 'text-gray-500 group-hover:text-white'}`} />
          <span className="text-sm font-bold truncate text-white">Devi Studio</span>
        </div>
        <div className="flex gap-2">
          <button onClick={onNewFile} title="New File" className="text-gray-500 hover:text-white transition-colors">
            <FilePlus size={14} />
          </button>
          <button onClick={() => fileInputRef.current?.click()} title="Open File (Import)" className="text-gray-500 hover:text-white transition-colors">
            <FolderOpen size={14} />
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileChange} 
          />
        </div>
      </div>

      <div className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-gray-500 flex justify-between items-center">
        <span>Explorer</span>
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-y-auto px-2">
        <FileTree 
          nodes={files} 
          activeFileId={activeFileId} 
          onSelectFile={onSelectFile} 
          level={0} 
        />
      </div>

      {/* Server Management Shortcut */}
      <div className="p-2">
        <button 
          onClick={onToggleServer}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
            isServerView ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-gray-400 hover:bg-[#1a1a1a] hover:text-white'
          }`}
        >
          <Globe size={16} className={isServerView ? 'animate-pulse' : ''} />
          <span className="text-sm font-medium">Server Manager</span>
        </button>
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-[#262626] flex items-center justify-around text-gray-500">
        <User size={18} className="cursor-pointer hover:text-white" />
        <Settings size={18} className="cursor-pointer hover:text-white" />
      </div>
    </div>
  );
};
