
import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { FileNode } from '../types';
import { X, Sparkles, Command } from 'lucide-react';
import { getCodeEdit } from '../services/geminiService';
import { HomeScreen } from './HomeScreen';

interface EditorContainerProps {
  activeFile: FileNode | null;
  openFiles: string[];
  files: FileNode[];
  onSelectFile: (id: string) => void;
  onCloseFile: (id: string) => void;
  onUpdateContent: (id: string, content: string) => void;
  findFile: (nodes: FileNode[], id: string) => FileNode | null;
  onNewFile: () => void;
  onUploadClick: () => void;
  onAISetup: (prompt: string) => void;
}

export const EditorContainer: React.FC<EditorContainerProps> = ({
  activeFile,
  openFiles,
  files,
  onSelectFile,
  onCloseFile,
  onUpdateContent,
  findFile,
  onNewFile,
  onUploadClick,
  onAISetup
}) => {
  const [isInlineEditOpen, setIsInlineEditOpen] = useState(false);
  const [inlinePrompt, setInlinePrompt] = useState('');
  const [isAILoading, setIsAILoading] = useState(false);

  // Ctrl+K shortcut for inline AI edit
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsInlineEditOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleInlineSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFile || !inlinePrompt.trim()) return;

    setIsAILoading(true);
    const result = await getCodeEdit(inlinePrompt, activeFile.content || '', activeFile.name);
    
    if (result) {
      onUpdateContent(activeFile.id, result);
    }
    
    setIsAILoading(false);
    setIsInlineEditOpen(false);
    setInlinePrompt('');
  };

  if (!activeFile) {
    return (
      <HomeScreen 
        onNewFile={onNewFile} 
        onUploadClick={onUploadClick} 
        onPromptSubmit={onAISetup} 
      />
    );
  }

  return (
    <div className="flex-1 flex flex-col min-w-0 relative overflow-hidden">
      {/* Tabs */}
      <div className="flex bg-[#0d0d0d] overflow-x-auto no-scrollbar border-b border-[#262626]">
        {openFiles.map(id => {
          const file = findFile(files, id);
          if (!file) return null;
          const isActive = activeFile.id === id;
          return (
            <div
              key={id}
              className={`flex items-center gap-2 px-3 py-2 border-r border-[#262626] cursor-pointer text-xs transition-all shrink-0 ${
                isActive ? 'bg-[#1a1a1a] text-white border-b border-b-blue-500' : 'text-gray-500 hover:bg-[#141414]'
              }`}
              onClick={() => onSelectFile(id)}
            >
              <span>{file.name}</span>
              <X
                size={12}
                className="hover:text-white"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseFile(id);
                }}
              />
            </div>
          );
        })}
      </div>

      {/* Editor */}
      <div className="flex-1 relative overflow-hidden">
        <Editor
          height="100%"
          theme="vs-dark"
          language={activeFile.language || 'javascript'}
          value={activeFile.content}
          onChange={(val) => onUpdateContent(activeFile.id, val || '')}
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            fontFamily: 'JetBrains Mono',
            lineNumbers: 'on',
            scrollBeyondLastLine: false,
            automaticLayout: true,
            padding: { top: 10, bottom: 10 },
            bracketPairColorization: { enabled: true },
            cursorBlinking: 'smooth',
            cursorSmoothCaretAnimation: 'on',
            backgroundColor: '#0d0d0d'
          }}
          loading={<div className="bg-[#0d0d0d] w-full h-full" />}
        />

        {/* Inline AI Edit Overlay */}
        {isInlineEditOpen && (
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full max-w-xl z-50 p-4">
            <form 
              onSubmit={handleInlineSubmit}
              className="bg-[#1a1a1a] border border-[#333] rounded-lg shadow-2xl p-1 flex items-center gap-2 focus-within:border-blue-500 transition-colors"
            >
              <div className="pl-3 text-blue-400">
                {isAILoading ? <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent" /> : <Sparkles size={18} />}
              </div>
              <input
                autoFocus
                className="bg-transparent border-none outline-none text-white text-sm flex-1 py-3"
                placeholder="How should I change this code? (Ctrl+K)"
                value={inlinePrompt}
                onChange={(e) => setInlinePrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') setIsInlineEditOpen(false);
                }}
              />
              <div className="flex items-center gap-1 pr-2">
                <kbd className="bg-[#2b2b2b] text-[10px] px-1 rounded text-gray-400 border border-[#444]">Enter</kbd>
                <span className="text-[10px] text-gray-600">to apply</span>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="h-6 bg-[#0d0d0d] border-t border-[#262626] flex items-center px-4 justify-between text-[10px] text-gray-500">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Command size={10} />
            <span>Main</span>
          </div>
          <span>UTF-8</span>
        </div>
        <div className="flex items-center gap-4">
          <span>{activeFile.language?.toUpperCase()}</span>
          <span>Spaces: 2</span>
          <span>Ln 1, Col 1</span>
        </div>
      </div>
    </div>
  );
};
