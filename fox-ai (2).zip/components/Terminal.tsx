
import React, { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, X, ChevronRight, Play, RotateCcw } from 'lucide-react';

interface TerminalProps {
  onClose: () => void;
}

export const Terminal: React.FC<TerminalProps> = ({ onClose }) => {
  const [history, setHistory] = useState<string[]>([
    'Devi HYTOPIA Build Environment v2.4.0',
    'Initializing world components...',
    '[SDK] Ready for deployment.'
  ]);
  const [input, setInput] = useState('');
  const [isBuilding, setIsBuilding] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  const addLog = (msg: string) => setHistory(prev => [...prev, msg]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isBuilding) return;

    const cmd = input.trim().toLowerCase();
    addLog(`devi@hytopia:~/project$ ${input}`);
    setInput('');

    setTimeout(() => {
      switch (cmd) {
        case 'build':
          startBuild();
          break;
        case 'help':
          addLog('Available commands: build, run, clean, ls, status, help');
          break;
        case 'status':
          addLog('[SYSTEM] CPU: 4%, Memory: 1.2GB/16GB, World State: IDLE');
          break;
        case 'ls':
          addLog('main.ts  project.json  assets/  README.md');
          break;
        case 'clear':
          setHistory([]);
          break;
        default:
          addLog(`bash: command not found: ${cmd}`);
      }
    }, 50);
  };

  const startBuild = () => {
    setIsBuilding(true);
    addLog('Starting HYTOPIA production build...');
    let progress = 0;
    const interval = setInterval(() => {
      progress += 20;
      addLog(`[Build] Compiling TypeScript files... ${progress}%`);
      if (progress >= 100) {
        clearInterval(interval);
        addLog('[Success] Build complete! Artifact saved to /dist');
        addLog('[Info] World server listening on port 3000');
        setIsBuilding(false);
      }
    }, 400);
  };

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d] border-t border-[#262626]">
      <div className="flex items-center justify-between px-4 py-1.5 bg-[#121212] border-b border-[#262626]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-gray-400">
            <TerminalIcon size={12} className="text-blue-500" />
            <span>Devi Terminal</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={startBuild}
              disabled={isBuilding}
              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-emerald-500 hover:text-emerald-400 disabled:opacity-50 transition-colors"
            >
              <Play size={10} fill="currentColor" />
              <span>Deploy</span>
            </button>
            <div className="h-3 w-px bg-[#262626]" />
            <button className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-gray-500 hover:text-white transition-colors">
              <RotateCcw size={10} />
              <span>Reset World</span>
            </button>
          </div>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-[#262626] rounded text-gray-500 transition-colors">
          <X size={14} />
        </button>
      </div>
      
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 font-mono text-sm text-gray-300 space-y-1 select-text"
      >
        {history.map((line, i) => (
          <div key={i} className={`whitespace-pre-wrap ${line.includes('[Success]') ? 'text-emerald-400' : line.includes('[Build]') ? 'text-blue-400' : ''}`}>
            {line}
          </div>
        ))}
        {!isBuilding && (
          <form onSubmit={handleCommand} className="flex items-center gap-2">
            <span className="text-blue-500 shrink-0 font-bold">devi@hytopia:~/project$</span>
            <input
              autoFocus
              className="flex-1 bg-transparent border-none outline-none text-gray-300"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
          </form>
        )}
      </div>
    </div>
  );
};
