
import React, { useState, useEffect } from 'react';
import { Activity, Play, Square, Users, Database, Globe, ShieldCheck, Terminal as TerminalIcon } from 'lucide-react';

export const ServerManager: React.FC = () => {
  const [status, setStatus] = useState<'offline' | 'starting' | 'online'>('offline');
  const [players, setPlayers] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-49), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const startServer = () => {
    if (status !== 'offline') return;
    setStatus('starting');
    addLog("Initializing WorldServer instance...");
    
    setTimeout(() => {
      addLog("Allocating network resources on port 3000...");
    }, 800);

    setTimeout(() => {
      addLog("Connecting to DataStorage (Postgres/Redis)...");
      addLog("Storage authenticated successfully.");
    }, 1500);

    setTimeout(() => {
      setStatus('online');
      addLog("Server ONLINE. Listening for connections.");
    }, 2500);
  };

  const stopServer = () => {
    setStatus('offline');
    setPlayers(0);
    addLog("Server SHUTDOWN initiated.");
    addLog("Saving world state to persistent storage...");
    addLog("Server OFFLINE.");
  };

  useEffect(() => {
    if (status === 'online') {
      const interval = setInterval(() => {
        setPlayers(p => Math.min(50, p + (Math.random() > 0.7 ? 1 : 0)));
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [status]);

  return (
    <div className="flex-1 flex flex-col bg-[#0d0d0d] overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-[#262626] flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl ${status === 'online' ? 'bg-emerald-500/10 text-emerald-500' : status === 'starting' ? 'bg-blue-500/10 text-blue-500' : 'bg-gray-500/10 text-gray-500'}`}>
            <Globe size={24} className={status === 'starting' ? 'animate-pulse' : ''} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Production Server</h2>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${status === 'online' ? 'bg-emerald-500' : status === 'starting' ? 'bg-blue-500' : 'bg-red-500'}`}></span>
              <span className="text-xs uppercase tracking-widest font-bold text-gray-500">{status}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-3">
          {status === 'offline' ? (
            <button 
              onClick={startServer}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-medium transition-all shadow-lg shadow-blue-900/20"
            >
              <Play size={16} fill="currentColor" />
              Create & Start Server
            </button>
          ) : (
            <button 
              onClick={stopServer}
              className="flex items-center gap-2 bg-red-600/10 hover:bg-red-600/20 text-red-500 border border-red-500/20 px-6 py-2 rounded-lg font-medium transition-all"
            >
              <Square size={16} fill="currentColor" />
              Stop Server
            </button>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-4 p-6 bg-[#0f0f0f]/50">
        <div className="bg-[#141414] border border-[#262626] p-4 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase font-bold">Players</span>
            <Users size={14} className="text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{players}/50</div>
        </div>
        <div className="bg-[#141414] border border-[#262626] p-4 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase font-bold">Uptime</span>
            <Activity size={14} className="text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white">{status === 'online' ? '12m 4s' : '--'}</div>
        </div>
        <div className="bg-[#141414] border border-[#262626] p-4 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase font-bold">Latency</span>
            <ShieldCheck size={14} className="text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white">{status === 'online' ? '14ms' : '--'}</div>
        </div>
        <div className="bg-[#141414] border border-[#262626] p-4 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500 uppercase font-bold">Storage</span>
            <Database size={14} className="text-orange-400" />
          </div>
          <div className="text-2xl font-bold text-white">{status === 'online' ? '1.2 GB' : '--'}</div>
        </div>
      </div>

      {/* Console Section */}
      <div className="flex-1 flex flex-col p-6 min-h-0">
        <div className="flex items-center gap-2 mb-3 text-xs font-bold text-gray-500 uppercase tracking-widest">
          <TerminalIcon size={14} />
          <span>Server Console</span>
        </div>
        <div className="flex-1 bg-black rounded-xl border border-[#262626] p-4 font-mono text-sm overflow-y-auto space-y-1">
          {logs.length === 0 ? (
            <div className="text-gray-700 italic">No activity logs. Start the server to begin orchestration.</div>
          ) : (
            logs.map((log, i) => (
              <div key={i} className="flex gap-2">
                <span className="text-blue-500 shrink-0 font-bold">SYS &gt;</span>
                <span className="text-gray-400">{log}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
