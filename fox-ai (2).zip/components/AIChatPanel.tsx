
import React, { useState, useRef, useEffect } from 'react';
import { FileNode, ChatMessage } from '../types';
import { X, Send, Sparkles, Code, Trash2, Zap, MessageSquare, BrainCircuit } from 'lucide-react';
import { getChatResponseStream } from '../services/geminiService';

interface AIChatPanelProps {
  activeFile: FileNode | null;
  onClose: () => void;
  initialPrompt?: string | null;
  onPromptConsumed?: () => void;
}

export const AIChatPanel: React.FC<AIChatPanelProps> = ({ 
  activeFile, 
  onClose, 
  initialPrompt,
  onPromptConsumed 
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    { label: "Refactor code", prompt: "Can you refactor the current file to be more performant and readable?" },
    { label: "Add unit tests", prompt: "Generate some Jest unit tests for the functions in this file." },
    { label: "Create API Route", prompt: "Show me how to create a POST endpoint for a task manager in Express." },
  ];

  useEffect(() => {
    if (initialPrompt) {
      handleSend(initialPrompt);
      onPromptConsumed?.();
    }
  }, [initialPrompt]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading, streamingText]);

  const handleSend = async (overrideInput?: string) => {
    const textToSend = overrideInput || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    if (!overrideInput) setInput('');
    setIsLoading(true);
    setStreamingText('');

    const history = messages.map(m => ({ role: m.role, content: m.content }));
    
    await getChatResponseStream(
      history, 
      textToSend, 
      activeFile?.content,
      (text) => {
        setStreamingText(text);
      }
    );

    setMessages(prev => [...prev, {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: streamingText || "How else can I help you?",
      timestamp: Date.now()
    }]);
    
    setStreamingText('');
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d]">
      {/* Header */}
      <div className="px-4 py-3 border-b border-[#262626] flex items-center justify-between bg-[#0d0d0d]">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-blue-600/10 rounded-lg">
            <BrainCircuit size={18} className="text-blue-500" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white leading-tight">Fox AI Assistant</h3>
            <p className="text-[10px] text-gray-500 font-medium">Next-Gen Engineering Partner</p>
          </div>
        </div>
        <div className="flex gap-1.5">
           <button 
            onClick={() => setMessages([])}
            className="p-1.5 hover:bg-[#262626] rounded-md text-gray-500 hover:text-red-400 transition-colors"
            title="Clear Chat"
          >
            <Trash2 size={16} />
          </button>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-[#262626] rounded-md text-gray-500 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Chat Canvas */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6 scroll-smooth">
        {messages.length === 0 && (
          <div className="flex flex-col h-full justify-center space-y-8 animate-in fade-in duration-700">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-blue-600 to-purple-600 p-0.5 mx-auto">
                <div className="w-full h-full bg-[#0d0d0d] rounded-3xl flex items-center justify-center">
                  <Sparkles size={28} className="text-blue-500" />
                </div>
              </div>
              <div className="space-y-1">
                <h4 className="text-lg font-bold text-white">Ask me anything</h4>
                <p className="text-xs text-gray-500 max-w-[240px] mx-auto">
                  I can write code, debug errors, and explain complex concepts in any language.
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-[10px] font-bold uppercase tracking-widest text-gray-600 px-2">Quick Tasks</p>
              <div className="grid grid-cols-1 gap-2">
                {suggestedPrompts.map((item, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(item.prompt)}
                    className="flex items-center gap-3 p-3 rounded-xl bg-[#141414] border border-[#262626] hover:border-blue-500/50 hover:bg-[#1a1a1a] transition-all text-left group"
                  >
                    <div className="p-2 bg-gray-800 rounded-lg group-hover:bg-blue-600/10 group-hover:text-blue-500 transition-colors">
                      <Zap size={14} />
                    </div>
                    <span className="text-xs font-medium text-gray-300 group-hover:text-white">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        
        {messages.map(msg => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-[92%] rounded-2xl p-4 text-sm leading-relaxed shadow-sm ${
              msg.role === 'user' 
                ? 'bg-[#1a1a1a] border border-[#333] text-gray-200' 
                : 'bg-transparent text-gray-300'
            }`}>
              {msg.role === 'assistant' && (
                <div className="flex items-center gap-2 mb-3 text-blue-500">
                  <BrainCircuit size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Fox Assistant</span>
                </div>
              )}
              <div className="whitespace-pre-wrap font-sans text-sm tracking-wide">
                {msg.content}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex flex-col items-start animate-in fade-in slide-in-from-bottom-2 duration-300">
             <div className="max-w-[92%] rounded-2xl p-4 text-sm leading-relaxed bg-transparent">
              <div className="flex items-center gap-2 mb-3 text-blue-400">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping" />
                <span className="text-[10px] font-black uppercase tracking-widest">Thinking...</span>
              </div>
              <div className="whitespace-pre-wrap font-sans text-sm tracking-wide text-gray-300">
                {streamingText || "Generating response..."}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Tray */}
      <div className="px-4 py-3 border-t border-[#262626] bg-[#0d0d0d]">
        <div className="flex items-center justify-between mb-2">
           {activeFile && (
            <div className="flex items-center gap-2 text-[10px] text-gray-500 bg-[#141414] px-2 py-1 rounded border border-[#262626]">
              <Code size={10} className="text-blue-500" />
              <span>Editing: <span className="text-gray-300">{activeFile.name}</span></span>
            </div>
          )}
          <div className="flex gap-2">
            <button className="text-[10px] text-gray-500 hover:text-white flex items-center gap-1 transition-colors">
              <MessageSquare size={10} />
              <span>History</span>
            </button>
          </div>
        </div>
        
        <div className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl blur opacity-0 group-focus-within:opacity-100 transition duration-500"></div>
          <div className="relative bg-[#141414] border border-[#262626] rounded-xl overflow-hidden focus-within:border-blue-600/50 transition-all">
            <textarea
              rows={1}
              className="w-full bg-transparent p-4 pr-12 text-sm text-white placeholder-gray-600 focus:outline-none resize-none overflow-hidden min-h-[52px]"
              placeholder="Ask me anything... (⌘L)"
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                e.target.style.height = 'auto';
                const newHeight = Math.min(e.target.scrollHeight, 240);
                e.target.style.height = newHeight + 'px';
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
            />
            <button 
              className="absolute right-3 bottom-3 p-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-all disabled:opacity-30 disabled:scale-95 shadow-lg shadow-blue-900/20 active:scale-90"
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
            >
              <Send size={14} />
            </button>
          </div>
        </div>
        <div className="mt-2 flex justify-center">
          <p className="text-[10px] text-gray-600 font-medium tracking-tight">⌘L to chat • ⌘K to edit inline</p>
        </div>
      </div>
    </div>
  );
};
