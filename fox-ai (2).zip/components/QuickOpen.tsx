
import React, { useState, useEffect, useRef } from 'react';
import { FileNode } from '../types';
import { Search, File } from 'lucide-react';

interface QuickOpenProps {
  files: FileNode[];
  onSelect: (fileId: string) => void;
  onClose: () => void;
}

export const QuickOpen: React.FC<QuickOpenProps> = ({ files, onSelect, onClose }) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // Flatten file tree to list of files
  const getAllFiles = (nodes: FileNode[]): FileNode[] => {
    let result: FileNode[] = [];
    nodes.forEach(node => {
      if (node.type === 'file') result.push(node);
      if (node.children) result = [...result, ...getAllFiles(node.children)];
    });
    return result;
  };

  const allFiles = getAllFiles(files);
  const filteredFiles = allFiles.filter(f => 
    f.name.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    inputRef.current?.focus();
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % filteredFiles.length);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + filteredFiles.length) % filteredFiles.length);
      }
      if (e.key === 'Enter' && filteredFiles[selectedIndex]) {
        onSelect(filteredFiles[selectedIndex].id);
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [filteredFiles, selectedIndex, onClose, onSelect]);

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-20 bg-black/40 backdrop-blur-sm">
      <div className="w-full max-w-xl bg-[#1a1a1a] border border-[#333] rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-150">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[#333]">
          <Search size={18} className="text-gray-500" />
          <input
            ref={inputRef}
            className="flex-1 bg-transparent border-none outline-none text-white text-sm"
            placeholder="Search files by name..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
          />
        </div>
        <div className="max-h-[400px] overflow-y-auto p-1">
          {filteredFiles.length > 0 ? (
            filteredFiles.map((file, idx) => (
              <div
                key={file.id}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                  idx === selectedIndex ? 'bg-blue-600 text-white' : 'hover:bg-[#2b2b2b] text-gray-300'
                }`}
                onClick={() => {
                  onSelect(file.id);
                  onClose();
                }}
              >
                <File size={16} className={idx === selectedIndex ? 'text-white' : 'text-gray-500'} />
                <div className="flex flex-col">
                  <span className="text-sm font-medium">{file.name}</span>
                  <span className={`text-[10px] ${idx === selectedIndex ? 'text-blue-100' : 'text-gray-600'}`}>
                    {file.language}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-gray-500 text-sm">
              No files matching "{query}"
            </div>
          )}
        </div>
        <div className="px-4 py-2 border-t border-[#333] bg-[#141414] text-[10px] text-gray-500 flex justify-between">
          <span>↑↓ to navigate</span>
          <span>↵ to open</span>
          <span>esc to dismiss</span>
        </div>
      </div>
    </div>
  );
};
