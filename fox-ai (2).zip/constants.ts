
import { FileNode } from './types';

export const INITIAL_FILES: FileNode[] = [
  {
    id: 'root',
    name: 'new-project',
    type: 'folder',
    children: [
      {
        id: 'index-ts',
        name: 'index.ts',
        type: 'file',
        language: 'typescript',
        content: `/**
 * Welcome to your new project!
 * I'm your AI assistant, ready to help you build anything.
 */

async function main() {
  console.log("Hello, World!");
  
  const greeting = greet("Developer");
  console.log(greeting);
}

function greet(name: string): string {
  return \`Welcome to Fox AI, \${name}!\`;
}

main();`
      },
      {
        id: 'package-json',
        name: 'package.json',
        type: 'file',
        language: 'json',
        content: `{
  "name": "my-awesome-app",
  "version": "1.0.0",
  "description": "A project built with Fox AI assistant",
  "main": "index.ts",
  "scripts": {
    "start": "ts-node index.ts",
    "build": "tsc",
    "test": "jest"
  },
  "dependencies": {
    "typescript": "^5.0.0"
  }
}`
      },
      {
        id: 'readme-md',
        name: 'README.md',
        type: 'file',
        language: 'markdown',
        content: `# My Awesome Project

This project was created using **Fox AI**, a high-performance code editor.

## Getting Started

1. Install dependencies
2. Run \`npm start\`
3. Let the AI help you build!
`
      }
    ]
  }
];

export const SYSTEM_INSTRUCTION = `You are Fox, a world-class AI Software Engineer embedded in a high-performance code editor.
You are similar to Cursor AI's assistant. You have deep expertise in all programming languages, frameworks, and modern software architecture.

Your Goal:
- Help the user write, debug, and optimize code across any domain (Web, Mobile, Backend, Games, AI).
- Provide clean, performant, and idiomatic code snippets.
- Be concise, professional, and highly capable.

Rules:
1. When editing code, focus on the user's specific request and return the improved logic.
2. If asked to "create a server", you can suggest Node.js (Express/Fastify), Python (FastAPI/Flask), or Go depending on the context.
3. You are no longer restricted to only HYTOPIA SDK; you are a general-purpose AI Engineering Partner.
4. Use modern patterns (Async/Await, Types, Composition).`;
