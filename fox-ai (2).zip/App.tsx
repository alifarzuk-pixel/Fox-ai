
import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { EditorContainer } from './components/EditorContainer';
import { AIChatPanel } from './components/AIChatPanel';
import { Terminal } from './components/Terminal';
import { QuickOpen } from './components/QuickOpen';
import { ServerManager } from './components/ServerManager';
import { INITIAL_FILES } from './constants';
import { FileNode, EditorState } from './types';

const App: React.FC = () => {
  const [files, setFiles] = useState<FileNode[]>(INITIAL_FILES);
  const [editorState, setEditorState] = useState<EditorState & { view: 'editor' | 'server' }>({
    activeFileId: null, // Start on Home Screen
    openFiles: ['index-ts', 'package-json'],
    view: 'editor'
  });
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isQuickOpenVisible, setIsQuickOpenVisible] = useState(false);
  const [initialPrompt, setInitialPrompt] = useState<string | null>(null);

  // Helper to find a file in the tree
  const findFile = useCallback((nodes: FileNode[], id: string): FileNode | null => {
    for (const node of nodes) {
      if (node.id === id) return node;
      if (node.children) {
        const found = findFile(node.children, id);
        if (found) return found;
      }
    }
    return null;
  }, []);

  const activeFile = editorState.activeFileId ? findFile(files, editorState.activeFileId) : null;

  const handleSelectFile = (fileId: string) => {
    setEditorState(prev => ({
      ...prev,
      view: 'editor',
      activeFileId: fileId,
      openFiles: prev.openFiles.includes(fileId) ? prev.openFiles : [...prev.openFiles, fileId]
    }));
  };

  const handleCloseFile = (fileId: string) => {
    setEditorState(prev => {
      const newOpenFiles = prev.openFiles.filter(id => id !== fileId);
      let newActiveId = prev.activeFileId;
      if (prev.activeFileId === fileId) {
        newActiveId = newOpenFiles.length > 0 ? newOpenFiles[newOpenFiles.length - 1] : null;
      }
      return {
        ...prev,
        activeFileId: newActiveId,
        openFiles: newOpenFiles
      };
    });
  };

  const handleUpdateContent = (fileId: string, content: string) => {
    const updateRecursive = (nodes: FileNode[]): FileNode[] => {
      return nodes.map(node => {
        if (node.id === fileId) return { ...node, content };
        if (node.children) return { ...node, children: updateRecursive(node.children) };
        return node;
      });
    };
    setFiles(prev => updateRecursive(prev));
  };

  const handleNewProject = () => {
    // Reset or set initial files if needed, then transition to editor
    setEditorState(prev => ({
      ...prev,
      view: 'editor',
      activeFileId: 'index-ts', // Open the main file
      openFiles: ['index-ts', 'package-json', 'readme-md']
    }));
    setIsTerminalOpen(true); // Open terminal as requested
    setIsSidebarCollapsed(false); // Ensure file area is visible
    setIsChatOpen(true); // Open AI chat for immediate assistance
  };

  const handleUploadFile = (name: string, content: string) => {
    const id = `upload-${Date.now()}`;
    const newFile: FileNode = {
      id,
      name,
      type: 'file',
      language: name.split('.').pop() || 'plaintext',
      content
    };

    setFiles(prev => {
      const root = prev.find(n => n.id === 'root');
      if (root) {
        return prev.map(n => n.id === 'root' ? { ...n, children: [...(n.children || []), newFile] } : n);
      }
      return [...prev, newFile];
    });
    
    handleSelectFile(id);
  };

  const handleAISetup = (promptText: string) => {
    setInitialPrompt(promptText);
    setIsChatOpen(true);
    if (!editorState.activeFileId) {
      handleSelectFile('index-ts');
    }
  };

  const toggleServerView = () => {
    setEditorState(prev => ({
      ...prev,
      view: prev.view === 'server' ? 'editor' : 'server',
      activeFileId: prev.view === 'server' ? prev.activeFileId : null
    }));
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'l') {
        e.preventDefault();
        setIsChatOpen(prev => !prev);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'b') {
        e.preventDefault();
        setIsSidebarCollapsed(prev => !prev);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === '`') {
        e.preventDefault();
        setIsTerminalOpen(prev => !prev);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'p') {
        e.preventDefault();
        setIsQuickOpenVisible(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0d0d0d] text-gray-300 select-none">
      {isQuickOpenVisible && (
        <QuickOpen 
          files={files} 
          onSelect={handleSelectFile} 
          onClose={() => setIsQuickOpenVisible(false)} 
        />
      )}

      {/* Sidebar */}
      <div 
        className={`transition-[width,opacity] duration-200 border-r border-[#262626] flex flex-col shrink-0 ${
          isSidebarCollapsed ? 'w-0 opacity-0 overflow-hidden' : 'w-64'
        }`}
      >
        <Sidebar 
          files={files} 
          activeFileId={editorState.activeFileId} 
          onSelectFile={handleSelectFile}
          onNewFile={() => {}} // Placeholder for adding a new file inside explorer
          onUploadFile={handleUploadFile}
          onGoHome={() => setEditorState(prev => ({ ...prev, activeFileId: null, view: 'editor' }))}
          onToggleServer={toggleServerView}
          isServerView={editorState.view === 'server'}
        />
      </div>

      {/* Editor Main Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#0d0d0d]">
        <div className="flex-1 flex flex-col min-h-0">
          {editorState.view === 'server' ? (
            <ServerManager />
          ) : (
            <EditorContainer 
              activeFile={activeFile}
              openFiles={editorState.openFiles}
              files={files}
              onSelectFile={handleSelectFile}
              onCloseFile={handleCloseFile}
              onUpdateContent={handleUpdateContent}
              findFile={findFile}
              onNewFile={handleNewProject} // Triggered from HomeScreen
              onUploadClick={() => document.querySelector<HTMLInputElement>('input[type="file"]')?.click()}
              onAISetup={handleAISetup}
              onToggleServer={toggleServerView}
            />
          )}
        </div>
        
        {/* Terminal Area */}
        <div 
          className={`transition-[height,opacity] duration-200 shrink-0 ${
            isTerminalOpen ? 'h-64' : 'h-0 opacity-0 overflow-hidden'
          }`}
        >
          <Terminal onClose={() => setIsTerminalOpen(false)} />
        </div>
      </main>

      {/* AI Chat Sidebar */}
      <div 
        className={`transition-[width,opacity] duration-200 border-l border-[#262626] flex flex-col bg-[#0d0d0d] shrink-0 ${
          isChatOpen ? 'w-[400px]' : 'w-0 opacity-0 overflow-hidden'
        }`}
      >
        <AIChatPanel 
          activeFile={activeFile} 
          onClose={() => setIsChatOpen(false)} 
          initialPrompt={initialPrompt}
          onPromptConsumed={() => setInitialPrompt(null)}
        />
      </div>
    </div>
  );
};

export default App;
